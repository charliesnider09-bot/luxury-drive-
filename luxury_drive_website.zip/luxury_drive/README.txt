LUXURY DRIVE — FREE WEBSITE STARTER

FILES
- index.html: website content
- style.css: design and responsive layout
- script.js: menu, date and demo signup interaction

FREE HOSTING WITH GITHUB PAGES
1. Create a free GitHub account (if you are eligible to create one).
2. Create a new public repository named luxury-drive.
3. Upload index.html, style.css, script.js and this README file.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Choose the main branch and the /(root) folder, then Save.
7. Wait for GitHub Pages to publish. Your site address will appear in Settings → Pages.

ALTERNATIVE: NETLIFY DROP
You can also create a free Netlify account and drag the unzipped website folder into its manual deploy area. Check the current free-plan terms before using any service.

IMPORTANT BEFORE LAUNCH
- The articles on the site are sample placeholder copy, not current reporting. Replace them with original, accurate articles and cite sources where appropriate.
- The images are loaded from Unsplash URLs and require an internet connection. Check each image's current license/usage terms before using it commercially; replace images if needed.
- The email signup is a demo only. It does not collect or store email addresses. Connect a reputable email-list provider before inviting subscriptions and add a privacy notice.
- The advertisement area is only a placeholder. No ads are running and no money is earned automatically by publishing the site.
- Ad networks have approval, traffic, content and payment requirements. Since the site owner is under 18, a parent or guardian may need to own or manage advertising/payment accounts. Do not enter false age or identity information.
- Add a real contact email and a privacy policy before collecting personal information or running ads.
- Hosting may be free, but optional services such as a custom domain, paid email tools or premium features can cost money.
